import Furniture from "./components/arya/index";
import Appliance from './components/arya/index1';
import Package from "./components/arya/index2";
import Electronic from './components/arya/index3';
import Fitness from './components/arya/index4';
import WFH from './components/arya/index5';
import Pack from './components/arya/packagein';
import Bed from "./components/arya/bedroomin";
import { Routes, Route } from "react-router-dom";

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/appliance" element={<Appliance />} />
        <Route path="/wfh" element={<WFH/>} />
        <Route path="/electronic" element={<Electronic/>} />
        <Route path="/fitness" element={<Fitness/>} />
        <Route path="/furniture" element={<Furniture />} />
        <Route path="/pack" element={<Package />} />
        <Route path="/Bed" element={<Bed />} />
        <Route path="/packfilter" element={<Pack/>} />
      </Routes>
    </div>
  );
}
export default App;
