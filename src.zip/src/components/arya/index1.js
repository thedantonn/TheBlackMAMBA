import React from "react";
import "./index.css";
import Homecard_appliance from "./Homecard_appliance";
const app=[
       
            {
              "Position": 1,
              "appimgUrl": "https://www.rentomojo.com/public/images/category/appliances-bg/washing-machines.jpg",
              "appimgname": "Washing Machines"
            },
            {
              "Position": 2,
              "appimgUrl": "https://www.rentomojo.com/public/images/category/appliances-bg/refrigerators-and-freezers.jpg",
              "appimgname": "Refrigerators & Freezers"
            },
            {
              "Position": 3,
              "appimgUrl": "https://www.rentomojo.com/public/images/category/appliances-bg/televisions.jpg",
              "appimgname": "Televisions"
            },
            {
              "Position": 4,
              "appimgUrl": "https://www.rentomojo.com/public/images/category/appliances-bg/air-conditioners.jpg",
              "appimgname": "Air Conditioners"
            },
            {
              "Position": 5,
              "appimgUrl": "https://www.rentomojo.com/public/images/category/appliances-bg/air-purifiers.jpg",
              "appimgname": "Water & Air Purifiers"
            },
            {
              "Position": 6,
              "appimgUrl": "https://www.rentomojo.com/public/images/category/appliances-bg/microwaves-and-induction-stoves.jpg",
              "appimgname": "Microwaves & Induction"
            },
            {
              "Position": 7,
              "appimgUrl": "https://www.rentomojo.com/public/images/category/appliances-bg/air-coolers.jpg",
              "appimgname": "Air Coolers"
            },
            {
              "Position": 8,
              "appimgUrl": "https://www.rentomojo.com/public/images/category/appliances-bg/dishwashers.jpg",
              "appimgname": "Dishwashers"
            }
        ];

function Appliance(){
    return(
      <div className="room_appliance">
        <h1>Browse by Appliance type</h1>
        <div id="app_id">
          {app.length ? (
            app.map((item)=>(
              <Homecard_appliance key={item.Position} item={item}/>
            ))
            ) :(
            <p>Nothing to show</p>
          )}
          </div>  
        </div>
    )
 }
export default Appliance;
