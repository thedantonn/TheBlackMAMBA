import React from "react";
function Package({item}){
    return(
        <div sx={{maxwidth:345}} className="p_type">
           
                <img  height="140" src={item.pimg} alt="error"/>
                <div id="pname">
                <div>{item.pname}</div>
                </div>
                <div id="price">
                <div>{item.price}</div>
                </div>

        </div>
    );
}
export default Package;