import React from "react";
function Homecard_furniture({item}){
    return(
        <div sx={{maxwidth:345}} className="furniture_type">
            <div>
                <img  height="250" src={item.imgUrl_div2}/>
                <div id="furniture_name">
                <div>{item.name_div2}</div>
                </div>
            </div>


        </div>
    );
}
export default Homecard_furniture;