import React from "react";
import "./index.css";
import Homecard_wfh from "./Homecard_wfh";
const w=[
    {
      "Position": 1,
      "wfhimg": "https://p.rmjo.in/productSquare/33o6pfrf-500x500.jpg",
      "wfhname": "Barney Leather Recliner (Brown)"
    },
    {
      "Position": 2,
      "wfhimg": "https://p.rmjo.in/productSquare/mnuazvk3-500x500.jpg",
      "wfhname": "Miller Office Chair"
    },
    {
      "Position": 3,
      "wfhimg": "https://p.rmjo.in/productSquare/d25jc9wi-500x500.jpg",
      "wfhname": "Poise Study Table"
    }
   ];
   function WFH(){
    return(
      <div className="room_wfh">
        <h1>Browse by WFH type</h1>
        <div id="w_id">
          {w.length ? (
            w.map((item)=>(
              <Homecard_wfh key={item.Position} item={item}/>
            ))
            ) :(
            <p>Nothing to show</p>
          )}
          </div> 
        </div>
    )
 }
export default WFH;