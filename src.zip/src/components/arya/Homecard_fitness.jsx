import React from "react";
function Homecard_fitness({item}){
    return(
        <div sx={{maxwidth:345}} className="fitness_type">
            <div>
                <img  height="165" src={item.fitimg}/>
                <div id="fitness_name">
                <div> {item.fitname}</div>
                </div>
            </div>


        </div>
    );
}
export default Homecard_fitness;