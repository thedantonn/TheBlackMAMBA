import React from "react";
function Homecard_electronic({item}){
    return(
        <div sx={{maxwidth:345}} className="electronic_type">
            <div>
                <img  height="165" src={item.eimg}/>
                <div id="electronic_name">
                <div> {item.ename}</div>
                </div>
            </div>


        </div>
    );
}
export default Homecard_electronic;