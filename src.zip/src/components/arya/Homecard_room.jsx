import React from "react";
function Homecard_room({item}){
    return(
        <div sx={{maxwidth:345}} className="room_type">
            <div>
                <img  height="180" src={item.imgUrl_div1}/>
                <div id="room_name">
                <div>{item.name_div1}</div>
                </div>
            </div>


        </div>
    );
}
export default Homecard_room;