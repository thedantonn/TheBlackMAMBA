import React from "react";
import "./index.css";
import Homecard_fitness from "./Homecard_fitness";
const fit=[
    {
      "Position": 1,
      "fitimg": "https://www.rentomojo.com/public/images/category/fitness/treadmills.jpg",
      "fitname": "Treadmills"
    },
    {
      "Position": 2,
      "fitimg": "https://www.rentomojo.com/public/images/category/fitness/cross-trainers.jpg",
      "fitname": "Cross Trainers"
    },
    {
      "Position": 3,
      "fitimg": "https://www.rentomojo.com/public/images/category/fitness/exercise-bikes.jpg",
      "fitname": "Exercise Bikes"
    },
    {
      "Position": 4,
      "fitimg": "https://www.rentomojo.com/public/images/category/fitness/massagers.png",
      "fitname": "Massagers"
    }
   ];
   function Fitness(){
    return(
      <div className="room_fitness">
        <h1>Browse by Fitness type</h1>
        <div id="fit_id">
          {fit.length ? (
            fit.map((item)=>(
              <Homecard_fitness key={item.Position} item={item}/>
            ))
            ) :(
            <p>Nothing to show</p>
          )}
          </div>
        </div>
    )
 }
export default Fitness;