import React from "react";
function Bedroom({item}){
    return(
        <div sx={{maxwidth:345}} className="bed_type">
           
                <img  height="250" src={item.bedimg} alt="error"/>
                <div id="bedname">
                <div>{item.bedname}</div>
                </div>
                <div id="bedprice">
                <div>{item.bedprice}</div>
                </div>

        </div>
    );
}
export default Bedroom;