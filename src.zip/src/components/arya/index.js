import React from "react";
import Homecard_room from "./Homecard_room";
import "./index.css";
import { Link } from "react-router-dom";
import Homecard_furniture from "./Homecard_furniture";


const room=[
    {
      "Position": 1,
      "imgUrl_div1": "https://www.rentomojo.com/public/images/category/package-bg/bedroom-v1_new.jpg",
      "name_div1": "Bedroom"
    },

    {
      "Position": 2,
      "imgUrl_div1": "https://www.rentomojo.com/public/images/category/package-bg/living-room-v2.jpg",
      "name_div1": "Living Room"
    },
    {
      "Position": 3,
      "imgUrl_div1": "https://www.rentomojo.com/public/images/category/package-bg/study-room-v1.jpg",
      "name_div1": "Work From Home (WFH)"
    },
    {
      "Position": 4,
      "imgUrl_div1": "https://www.rentomojo.com/public/images/category/package-bg/dining-v1.jpg",
      "name_div1": "Kitchen & Dining"
    },
    {
      "Position": 5,
      "imgUrl_div1": "https://www.rentomojo.com/public/images/category/package-bg/baby-furniture.jpg",
      "name_div1": "Baby Furniture"
    }
   ];
   const furniture=[
    {
      "Position": 1,
      "imgUrl_div2": "https://www.rentomojo.com/public/images/category/furniture-category-filter/Beds.jpg",
      "name_div2": "Beds"
    },
    {
      "Position": 2,
      "imgUrl_div2": "https://www.rentomojo.com/public/images/category/furniture-category-filter/mattress_v1.jpg",
      "name_div2": "Mattresses"
    },
    {
      "Position": 3,
      "imgUrl_div2": "https://www.rentomojo.com/public/images/category/furniture-category-filter/Wardrobes_and_Organiser.jpg",
      "name_div2": "Wardrobe & Organizer"
    },
    {
      "Position": 4,
      "imgUrl_div2": "https://www.rentomojo.com/public/images/category/furniture-category-filter/Chest_of_Drawer.jpg",
      "name_div2": "Chest of Drawers"
    },
    {
      "Position": 8,
      "imgUrl_div2": "https://www.rentomojo.com/public/images/category/furniture-category-filter/Recliner.jpg",
      "name_div2": "Recliner and Rocker",
    },
    {
      "Position": 9,
      "imgUrl_div2": "https://www.rentomojo.com/public/images/category/furniture-category-filter/15_TV%20Units.png",
      "name_div2": "TV Units"
    },
    {
      "Position": 10,
      "imgUrl_div2": "https://www.rentomojo.com/public/images/category/furniture-category-filter/101-dresser.png",
      "name_div2": "Dressers"
    },
    {
      "Position": 11,
      "imgUrl_div2": "https://www.rentomojo.com/public/images/category/furniture-category-filter/16_Shoe%20Racks.png",
      "name_div2": "Shoe Racks"
    },
    {
      "Position": 12,
      "imgUrl_div2": "https://www.rentomojo.com/public/images/category/furniture-category-filter/19_Chairs.png",
      "name_div2": "Chairs & Stools"
    },
    {
      "Position": 13,
      "imgUrl_div2": "https://www.rentomojo.com/public/images/category/furniture-category-filter/Center-Table.jpg",
      "name_div2": "Center Tables"
    },
    {
      "Position": 14,
      "imgUrl_div2": "https://www.rentomojo.com/public/images/category/furniture-category-filter/BookShelf.jpg",
      "name_div2": "Bookshelves & Display"
    },
    {
      "Position": 15,
      "imgUrl_div2": "https://www.rentomojo.com/public/images/category/furniture-category-filter/Study_Table.jpg",
      "name_div2": "Study Tables"
    },
    {
      "Position": 16,
      "imgUrl_div2": "https://www.rentomojo.com/public/images/category/furniture-category-filter/Dining_Table.jpg",
      "name_div2": "Dining Tables"
    },
  
   ];

   function Furniture(){
    return(
      <div className="room_furniture">
        <h1>Browse by Room type</h1>
        <div id="type_id">
            {room.length ? (
            room.map((item)=>(
              <Homecard_room key={item.Position} item={item}/>
            ))
            ) :(
            <p>Nothing to show</p>
          )}
        </div>
        <Link to={"/Bed"}><h1> 🛏️ </h1></Link> 
        <h1>Browse by Furniture type</h1>
        <div id="fur_id">
          {furniture.length ? (
            furniture.map((item)=>(
              <Homecard_furniture key={item.Position} item={item}/>
            ))
            ) :(
            <p>Nothing to show</p>
          )}
        </div>
        
      </div>
    )
   }
   export default Furniture;