import React from "react";
import "./index.css";
import Package from "./Package";
const p=[
    {
      "Position": 1,
      "pimg": "https://p.rmjo.in/moodShot/vgqeajhe-1024x512.jpg",
      "pname": "Washing Machine with Fridge & Kent Water Purifier",
      "price":"₹686/ mo"
    },
    {
      "Position": 2,
      "pimg": "https://p.rmjo.in/moodShot/vgqeajhe-1024x512.jpg",
      "pname": "Kipper Basic Bedroom",
      "price":"₹686/ mo"
    },
    {
      "Position": 3,
      "pimg": "https://p.rmjo.in/moodShot/omkdax17-1024x512.jpg",
      "pname": "Fridge & Induction Combo",
      "price":"₹686/ mo"
    },
    {
      "Position": 4,
      "pimg": "https://p.rmjo.in/moodShot/lcc7ot7j-1024x512.jpg",
      "pname": "Hutch 2-Door Wardrobe & Saddle Shoe Rack",
      "price":"₹686/ mo"
    },
    {
      "Position": 5,
      "pimg": "https://p.rmjo.in/moodShot/ovlbp5do-1024x512.jpg",
      "pname": "Cricket SuperNova Package",
      "price":"₹686/ mo"
    },
   
    {
      "Position": 8,
      "pimg": "https://p.rmjo.in/moodShot/nhn0gk1m-1024x512.jpg",
      "pname": "Cricket Mania Package",
      "price":"₹686/ mo"
    },
   
    {
      "Position": 10,
      "pimg": "https://p.rmjo.in/moodShot/d46cg5a5-1024x512.jpg",
      "pname": "Silly Mid Off Package",
      "price":"₹686/ mo"
    },
   ];

   function Pack(){
    return(
      <div className="room_pack">
        <h1>Packages</h1>
        <div id="p_id">
          {p.length ? (
            p.map((item)=>(
              <Package key={item.Position} item={item}/>
            ))
            ) :(
            <p>Nothing to show</p>
          )}
          </div>
          
        </div>
    )
 }
export default Pack;
