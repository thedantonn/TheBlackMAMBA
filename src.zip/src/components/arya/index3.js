import React from "react";
import "./index.css";
import Homecard_electronic from "./Homecard_electronic";
const elec=
    [
        {
          "Position": 1,
          "eimg": "https://www.rentomojo.com/public/images/category/appliances-bg/smartphones_new.jpg",
          "ename": "Smartphones"
        },
        {
          "Position": 2,
          "eimg": "https://www.rentomojo.com/public/images/category/appliances-bg/smart-devices-v1_new.jpg",
          "ename": "Smart Devices"
        },
        {
          "Position": 3,
          "eimg": "https://www.rentomojo.com/public/images/category/appliances-bg/laptops_new_2.jpg",
          "ename": "Laptops"
        },
        {
          "Position": 4,
          "eimg": "https://www.rentomojo.com/public/images/category/appliances-bg/tablets_new.jpg",
          "ename": "Tablets"
        }
       ];

       function Electronic(){
        return(
          <div className="room_electronic">
            <h1>Browse by Electronic type</h1>
            <div id="elec_id">
              {elec.length ? (
                elec.map((item)=>(
                  <Homecard_electronic key={item.Position} item={item}/>
                ))
                ) :(
                <p>Nothing to show</p>
              )}
              </div> 
            </div>
        )
     }
    export default Electronic;