import React from "react";
function Homecard_wfh({item}){
    return(
        <div sx={{maxwidth:345}} className="wfh_type">
            <div>
                <img  height="250" src={item.wfhimg}/>
                <div id="wfh_name">
                <div>{item.wfhname}</div>
                </div>
            </div>
            </div>
    );
}
export default Homecard_wfh;