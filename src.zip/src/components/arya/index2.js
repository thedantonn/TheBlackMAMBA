import React from "react";
import "./index.css";
import Homecard_package from "./Homecard_package";
import { Link } from "react-router-dom";
const pack=[
        {
          "Position": 1,
          "packimg": "https://www.rentomojo.com/public/images/category/package-bg/bedroom-v1_new.jpg",
          "packname": "Bedroom\n21 Package(s)"
        },
        {
          "Position": 2,
          "packimg": "https://www.rentomojo.com/public/images/category/package-bg/living-room-v2.jpg",
          "packname": "Living Room\n14 Package(s)"
        },
        {
          "Position": 3,
          "packimg": "https://www.rentomojo.com/public/images/category/package-bg/appliances.jpg",
          "packname": "Appliances\n20 Package(s)"
        },
        {
          "Position": 4,
          "packimg": "https://www.rentomojo.com/public/images/category/package-bg/study-room-v1.jpg",
          "packname": "Work From Home (WFH)\n6 Package(s)"
        },
        {
          "Position": 5,
          "packimg": "https://www.rentomojo.com/public/images/category/package-bg/dining-v1.jpg",
          "packname": "Kitchen & Dining\n2 Package(s)"
        },
        {
          "Position": 6,
          "packimg": "https://www.rentomojo.com/public/images/category/package-bg/smart-packages.jpg",
          "packname": "Smart Home\n3 Package(s)"
        },
        {
          "Position": 7,
          "packimg": "https://www.rentomojo.com/public/images/category/package-bg/fitness-packages.jpg",
          "packname": "Fitness & Exercise\n1 Package(s)"
        }
];

function Package(){
    return(
      <div className="room_package">
        <h1>Browse by Package type</h1>
        <div id="pack_id">
          {pack.length ? (
            pack.map((item)=>(
              <Homecard_package key={item.Position} item={item}/>
            ))
            ) :(
            <p>Nothing to show</p>
          )}
          </div>
          <Link to={"/packfilter"}><h1>Packages</h1></Link>  
            
        </div>
        
        
    )
 }
export default Package;
