import React from "react";
function Homecard_package({item}){
    return(
        <div sx={{maxwidth:345}} className="package_type">
            <div>
                <a href="/Pack">
                <img  height="140" src={item.packimg}/>
                </a>
                <div id="package_name">
                <div> {item.packname}</div>
                </div>
            </div>


        </div>
    );
}
export default Homecard_package;
