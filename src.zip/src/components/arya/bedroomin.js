import React from "react";
import "./index.css";
import Bedroom from "./Bed_room";
const bed=[
        {
          "Position": 1,
          "bedimg": "https://p.rmjo.in/productSquare/5oprmbr9-500x500.jpg",
          "bedname": "Kipper Wooden Chest of Drawers ( Walnut )",
          "bedprice": "₹309/ mo"
        },
        {
          "Position": 2,
          "bedimg": "https://p.rmjo.in/productSquare/tv0z9mjt-500x500.jpg",
          "bedname": "Filbert Chest of Drawers (Walnut)",
          "bedprice": "₹269/ mo"
        },
        {
          "Position": 3,
          "bedimg": "https://p.rmjo.in/productSquare/6cxh0dx0-500x500.jpg",
          "bedname": "Minion Bedside Table (Walnut)",
          "bedprice": "₹109/ mo"
        },
        {
          "Position": 4,
          "bedimg": "https://p.rmjo.in/productSquare/hav8htp0-500x500.jpg",
          "bedname": "Betty Dresser with Stool (Walnut)",
          "bedprice": "₹209/ mo"
        },
        {
          "Position": 5,
          "bedimg": "https://p.rmjo.in/productSquare/60jwnd8r-500x500.jpg",
          "bedname": "Betty Dressing Table ( Walnut )",
          "bedprice": "₹275/ mo"
        },
        {
          "Position": 6,
          "bedimg": "https://p.rmjo.in/productSquare/zx904utg-500x500.jpg",
          "bedname": "Brook Dressing Table (Walnut)",
          "bedprice": "₹289/ mo"
        },
        {
          "Position": 7,
          "bedimg": "https://p.rmjo.in/productSquare/a7y7p2va-500x500.jpg",
          "bedname": "Brooklyn Ottoman with Storage (Charcoal Grey)",
          "bedprice": "₹185/ mo"
        },
        {
          "Position": 8,
          "bedimg": "https://p.rmjo.in/productSquare/vvaw3a50-500x500.jpg",
          "bedname": "Stowy 1- Door Wardrobe (Walnut)",
          "bedprice": "₹329/ mo"
        },
        {
          "Position": 9,
          "bedimg": "https://p.rmjo.in/productSquare/jtbi5m0s-500x500.jpg",
          "bedname": "Stowy 2- Door Wardrobe (Walnut)",
          "bedprice": "₹449/ mo"
        },
       
        {
          "Position": 11,
          "bedimg": "https://p.rmjo.in/productSquare/6atde1sz-500x500.jpg",
          "bedname": "Ladder open bookshelf (Walnut)",
          "bedprice": "₹279/ mo"
        },
        {
          "Position": 12,
          "bedimg": "https://p.rmjo.in/productSquare/vpcwnx6d-500x500.jpg",
          "bedname": "Hudson Chest of Drawer (Walnut)",
          "bedprice": "₹429/ mo"
        },
        {
          "Position": 13,
          "bedimg": "https://p.rmjo.in/productSquare/lqebh89r-500x500.jpg",
          "bedname": "Pearl 3 Door wardrobe (Walnut)",
          "bedprice": "₹832/ mo"
        },
        {
          "Position": 14,
          "bedimg": "https://p.rmjo.in/productSquare/jic4j4hh-500x500.jpg",
          "bedname": "Napster Metal Queen Bed (6x5)",
          "bedprice": "₹349/ mo"
        },
        {
          "Position": 15,
          "bedimg": "https://p.rmjo.in/productSquare/ygmpue5m-500x500.jpg",
          "bedname": "Aurora Wooden Queen Bed (6x5)",
          "bedprice": "₹558/ mo"
        },
        {
          "Position": 16,
          "bedimg": "https://p.rmjo.in/productSquare/nuj33rrq-500x500.jpg",
          "bedname": "Napster Metal Single Bed (6x3)",
          "bedprice": "₹225/ mo"
        },
        {
          "Position": 17,
          "bedimg": "https://p.rmjo.in/productSquare/tncocgko-500x500.jpg",
          "bedname": "Poise Wooden Queen Bed (6x5)",
          "bedprice": "₹568/ mo"
        },
        {
          "Position": 18,
          "bedimg": "https://p.rmjo.in/productSquare/lpm7f0x2-500x500.jpg",
          "bedname": "Poise Wooden King Bed (78*72 inches)",
          "bedprice": "₹692/ mo"
        },
      
        {
          "Position": 20,
          "bedimg": "https://p.rmjo.in/productSquare/lkyt2ba7-500x500.jpg",
          "bedname": "Aurora Wooden Single Bed (6x3)",
          "bedprice": "₹423/ mo"
        },
        {
          "Position": 21,
          "bedimg": "https://p.rmjo.in/productSquare/oxxqocpy-500x500.jpg",
          "bedname": "Kipper Wooden Queen Bed (6x5)",
          "bedprice": "₹749/ mo"
        },
      
        {
          "Position": 23,
          "bedimg": "https://p.rmjo.in/productSquare/bfxhsqxe-500x500.jpg",
          "bedname": "Poise Wooden Single Bed (6.5x3)",
          "bedprice": "₹389/ mo"
        },
        {
          "Position": 24,
          "bedimg": "https://p.rmjo.in/productSquare/zjw3byn9-500x500.jpg",
          "bedname": "Kipper Wooden Single Bed (6x3)",
          "bedprice": "₹409/ mo"
        },
        {
          "Position": 25,
          "bedimg": "https://p.rmjo.in/productSquare/zxd12r4b-500x500.jpg",
          "bedname": "Queen Foam Mattress (6x5)",
          "bedprice": "₹259/ mo"
        },
        {
          "Position": 26,
          "bedimg": "https://p.rmjo.in/productSquare/ymdnjn7h-500x500.jpg",
          "bedname": "Queen Coir & Foam Mattress (6x5)",
          "bedprice": "₹299/ mo"
        },
        {
          "Position": 27,
          "bedimg": "https://p.rmjo.in/productSquare/h98dzvch-500x500.jpg",
          "bedname": "Single Foam Mattress (6x3)",
          "bedprice": "₹149/ mo"
        },
      
      
       
];


function Bed(){
    return(
      <div className="room_bed">
        <h1>Bedroom</h1>
        <div id="bed_id">
          {bed.length ? (
            bed.map((item)=>(
              <Bedroom key={item.Position} item={item}/>
            ))
            ) :(
            <p>Nothing to show</p>
          )}
          </div>
          
        </div>
    )
 }
export default Bed;