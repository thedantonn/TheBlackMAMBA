import React from "react";
function Homecard_appliance({item}){
    return(
        <div sx={{maxwidth:345}} className="appliance_type">
            <div>
                <img  height="140" src={item.appimgUrl}/>
                <div id="appliance_name">
                <div>{item.appimgname}</div>
                </div>
            </div>


        </div>
    );
}
export default Homecard_appliance;